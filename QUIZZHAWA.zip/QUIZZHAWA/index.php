<?php

//http://localhost/int%c3%a9gration/Quizz
   define("WEBROOT","http://127.0.0.1/Integration/Integration/QUIZZ");
   
   require_once "libs/Router.php";
   $router=new Router();
   $router->getRoute();
   
  
